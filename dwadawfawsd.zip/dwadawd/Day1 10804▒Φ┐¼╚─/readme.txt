📘 Day 1 과제 시나리오
HTML 기본 구조와 시맨틱 태그를 활용하여 '나를 소개하는 웹페이지'의 기본 뼈대를 구성한다.

📂 포함된 파일:
- index_student.html / style_student.css: 학생용 과제 파일
- index_teacher.html / style_teacher.css: 교사용 정답 예시
