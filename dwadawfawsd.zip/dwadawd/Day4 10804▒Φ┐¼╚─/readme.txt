📘 Day 4 과제 시나리오
CSS 박스모델을 활용하여 연습하고 박스모델을 시각화 해본다.

📂 포함된 파일:
- index_student.html / style_student.css: 학생용 과제 파일
- index_teacher.html / style_teacher.css: 교사용 정답 예시
