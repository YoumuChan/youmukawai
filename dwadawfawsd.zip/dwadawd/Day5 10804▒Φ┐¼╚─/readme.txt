📘 Day 5 과제 시나리오
﻿Flexbox를 사용하여 '상품목록' 레이아웃을 하드코딩으로 제작한다.

📂 포함된 파일:
- index_student.html / style_student.css: 학생용 과제 파일
- index_teacher.html / style_teacher.css: 교사용 정답 예시
